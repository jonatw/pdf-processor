mupdf_location = 'https://mupdf.com/downloads/archive/mupdf-1.26.11-source.tar.gz'
pymupdf_version = '1.26.7'
pymupdf_version_tuple = (1, 26, 7)
pymupdf_git_sha = '1084c91bdedea2ebae144eb014a1519eb55ed7a2'
pymupdf_git_diff = ''
pymupdf_git_branch = 'main'
swig_version = '4.3.1'
swig_version_tuple = (4, 3, 1)
